/*
A simple demo illustrating the Mappa.js library
https://mappa.js.org/

we're using Mappa as a wrapper for Leaflet. more functionality here
https://leafletjs.com/reference.html
*/

let myMap;
let canvas;
const mappa = new Mappa("Leaflet");
var locations;
var dates;
var crashes = [];
var screenstate = 0;
var WELCOME = 0;
var MAPPING = 1;
var mapIsVisible = true;
var colors;
var img;
var font;
var current;
var Switch = false
var constructions = []

const options = {
  lat: 49.2820, 
  lng: -123.116226,
  zoom: 11,
  // style: "http://{s}.tile.osm.org/{z}/{x}/{y}.png",
  style: "http://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png",
};

//load a csv file
function preload() {
  locations = loadTable("Upcoming_Project.csv", "csv", "header");
  dates = loadTable("Dates.csv", "csv", "header");
  img = loadImage("vancouver.jpeg")
  font = loadFont("fonts.otf");
  current = loadTable("Under_Construction.csv", "csv", "header")
}

function setup() {
  //Mappa boilerplate..
  canvas = createCanvas(1500, 800);
  myMap = mappa.tileMap(options);
  myMap.onChange(drawMap); //draw function for map
  myMap.overlay(canvas); //normal draw loop (aka canvas) gets drawn on top
  textFont(font)

  for (let row = 0; row < locations.getRowCount(); row++) {
    var cell = locations.get(row, 0);
    var cells = cell.split(",");
    var lat = parseFloat(cells[0]);
    var lon = parseFloat(cells[1]);
    var month = parseInt(dates.get(row, 0));
    crashes[row] = new Crash(lat, lon, month);
    if (row<current.getRowCount()){
      var cell1 = current.get(row,0);
      var cell1s = cell1.split(",");
      
    
    }
   
  }
}

//used for all screenstates except map
function draw() {  
  if (screenstate == WELCOME) {
    background(img);

    

    textSize(30);
    textAlign(CENTER);
    textSize(22);
    fill(255)
    strokeWeight(2.5)
    rect(width/2-100, height/2-15, 200, 100)
    fill(0)
    text("[W]elcome screen", width / 2, height / 2 + 30);
    text("[M]ap screen", width / 2, height / 2 + 60);
    fill(255)
    strokeWeight(5)
    textSize(45)
    text("Upcoming City Projects Map", width / 2, height / 2-50);
  } else if (screenstate == MAPPING) {
    //show nothing
  }
  
  //yes, this is a hack.. Mappa won't let us hide in setup
  if(frameCount == 5) { hideMap(); }
}

//used for map screenstate -- only redraws when the map changes (i.e. not every frame).
function drawMap() {
  if (screenstate == WELCOME) {
    //show nothing
  } else if (screenstate == MAPPING) {
    clear(); //clear the map overlay

    if (!Switch) {
    for (let crash of crashes) {
      crash.drawMe();
    }
  }   else {
      for (let construction of constructions) {
        construction.drawMe();
    }
  }
    drawLegend();
  }
}

function keyPressed() {
  //note: Mappa sometimes converts input to uppercase for some weird reason
  let k = key.toLowerCase();
  
  if (k == "m") {
    
    if (key =='s') {
    Switch = !Switch;
    loadDataset();
    drawMap();}
    screenstate = MAPPING;
    showMap();
    drawMap(); //need to call this once the first time
    mapIsVisible = true;
  } else if (k == "w") {
    screenstate = WELCOME;
    hideMap();
    mapIsVisible = false;
  }

  if (screenstate == MAPPING) {
    if (k == "d") {
      //fly to downtown
      myMap.map.flyTo([49.2825, -123.1186], 16);
    } else if (k == "p") {
      //fly to PG
      myMap.map.flyTo([49.2610, -123.2001], 16);      
    }
    else if (k == "g") {
      //fly to Granville
      myMap.map.flyTo([49.2139, -123.1406], 14);  }
  }  
}

//utility functions to enable/disable map functionality when unneeded
function hideMap() {
  mapIsVisible = false; //a local flag 
  myMap.map.removeControl( myMap.map.zoomControl ); //the +/- buttons
  myMap.map.removeControl( myMap.map.attributionControl ); //the "Leaflet" logo
  
  //disable zoom when hidden
  myMap.map.touchZoom.disable();
  myMap.map.doubleClickZoom.disable();
  myMap.map.scrollWheelZoom.disable();
  myMap.map.boxZoom.disable();
  myMap.map.keyboard.disable();
}

function showMap() {
  mapIsVisible = true;
  myMap.map.addControl( myMap.map.zoomControl ); 
  myMap.map.addControl( myMap.map.attributionControl ); 
  
  //enable zoom when hidden
  myMap.map.touchZoom.enable();
  myMap.map.doubleClickZoom.enable();
  myMap.map.scrollWheelZoom.enable();
  myMap.map.boxZoom.enable();
  myMap.map.keyboard.enable();
}
