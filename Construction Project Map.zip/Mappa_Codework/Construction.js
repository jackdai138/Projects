//A class that corresponds to one row of the data file
class Crash {
  constructor(a, b, month=null) {
    this.latitude = a;
    this.longitude = b;
    this.month = month;
    this.color = month ? this.determineColor() : [0, 0, 0];
  }


  determineColor() {
    if (this.month <= 3) {
      return [0, 204, 0]; // Green
    } else if (this.month <= 6) {
      return [102, 178, 255]; // Blue
    } else if (this.month <= 9) {
      return [255, 200, 20]; // Yellow
    } else {
      return [255, 182, 193]; // Light Yellow
    }
  }

  drawMe() {
    var coords = myMap.latLngToPixel(this.latitude, this.longitude);
    var size = map(myMap.getZoom(), 10, 16, 3, 15);
    fill(...this.color);
    noStroke();
    circle(coords.x, coords.y, size);
  }
}
