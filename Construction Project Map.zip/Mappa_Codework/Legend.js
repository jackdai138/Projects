function drawLegend() {
  let legendX = 1300;
  let legendY = 20;
  let legendWidth = 180;
  let legendHeight = 180;

  const colors = [color(0, 204, 0), color(102, 178, 255), color(255, 200, 20), color(255, 182, 193)]; // green, blue, yellow, light yellow
  const labels = ['Jan - Mar', 'Apr - Jun', 'Jul - Sep', 'Oct - Dec', "[D]owntown", "[G]ranville", "[P]oint Grey"];

  fill(255); 
  strokeWeight(2.5)
  stroke(0);
  rect(legendX, legendY, legendWidth, legendHeight);

  noStroke();
  for (let i = 0; i < colors.length; i++) {
    fill(colors[i]);
    let swatchX = legendX + 10;
    let swatchY = legendY + 10 + i * 25;
    let swatchSize = 20;
    rect(swatchX, swatchY, swatchSize, swatchSize);

    fill(0);
    textSize(14);
    textAlign(LEFT, CENTER);
    text(labels[i], swatchX + 30, swatchY + swatchSize / 2);
    text(labels[4], swatchX + 30, 140);
    text(labels[5], swatchX + 30, 160);
    text(labels[6], swatchX + 30, 180);
  }
}
