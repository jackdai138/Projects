class Construction {
  constructor(a, b) {
    this.latitude = a;
    this.longitude = b;
  }

  drawMe() {
    var coords = myMap.latLngToPixel(this.latitude, this.longitude);
    var size = map(myMap.getZoom(), 10, 16, 3, 15);
    fill(0);
    noStroke();
    circle(coords.x, coords.y, size);
  }
}

function loadDataset() {
  crashes = [];
  constructions = [];

  if (Switch) {
    for (let row = 0; row < current.getRowCount(); row++) {
      let lat = current.getNum(row, "Latitude");
      let lon = current.getNum(row, "Longitude");
      constructions.push(new Construction(lat, lon));
    }
  } else {
    for (let row = 0; row < locations.getRowCount(); row++) {
      var cell = locations.get(row, 0);
      var cells = cell.split(",");
      var lat = parseFloat(cells[0]);
      var lon = parseFloat(cells[1]);
      var month = dates.getNum(row, 0);
      crashes.push(new Crash(lat, lon, month));
    }
  }
}
