class Satellite {
  constructor(name, id, latitude, longitude, velocity, visibility, altitude) {
    this.name = name;
    this.id = id;
    this.latitude = latitude;
    this.longitude = longitude;
    this.velocity = velocity;
    this.visibility = visibility;
    this.altitude = altitude;
    this.positions = []; 
    this.altitudes = []; 
    this.velocities = []; 
  }

 
display(myMap) {
  stroke(255, 0, 0);
  strokeWeight(3);
  noFill();
  beginShape();
  for (let pos of this.positions) {
    const pixelPos = myMap.latLngToPixel(pos.lat, pos.lng);
    vertex(pixelPos.x, pixelPos.y);
  }
  endShape();

  const latestPos = myMap.latLngToPixel(this.latitude, this.longitude);
  fill(255, 0, 0);
  noStroke();
  textSize(32);
  text('🛰', latestPos.x, latestPos.y);
}

updatePosition(latitude, longitude) {
  this.latitude = latitude;
  this.longitude = longitude;
  this.positions.push({lat: latitude, lng: longitude});
  function updateISSPosition(data) {
  if (!iss) {
    iss = new Satellite(data.name, data.id, data.latitude, data.longitude, data.velocity, data.visibility);
  } else {
    iss.updatePosition(data.latitude, data.longitude, data.velocity);
  }

  updateVelocity(data.velocity);
  fetchCountry(data.latitude, data.longitude);
}
}


  drawLegend() {
    textSize(14);
    fill(255);
    noStroke();
    

    fill(0, 100);
    rect(width-250, 10, 180, 110);
    
    fill(255);
    
    text(`Name: ${this.name}`, width-240, 30);
    text(`ID: ${this.id}`, width-240, 45);
    text(`Latitude: ${this.latitude.toFixed(2)}`, width-240, height-740);
    text(`Longitude: ${this.longitude.toFixed(2)}`, width-240, height-725);
    text(`Velocity: ${this.velocity.toFixed(2)} km/h`, width-240, height-710);
    text(`Visibility: ${this.visibility}`, width-240, height-695);
  }
}
