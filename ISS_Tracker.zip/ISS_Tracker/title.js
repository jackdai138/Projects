function drawTitle() {
  let title = "ISS Tracker 🛰";
  textSize(40);
  textAlign(CENTER, CENTER);
  fill(50, 50, 50, 150);
  noStroke();

  rect(width / 2 - textWidth(title) / 2 - 10, 10, textWidth(title) + 20, 60, 10); 
  fill(255); 
  stroke(0); 
  strokeWeight(1);
  text(title, width / 2, 40); 
}

function resetTextProperties() {
  textAlign(LEFT, BASELINE); 
  noStroke(); 
  textSize(16); 
  fill(0);
}
