
// Mappa configuration for a Leaflet map
let startTime;
let canvas;
let velocities = []; 
const mappa = new Mappa('Leaflet');
let myMap;
let issLatitude = 0;
let issLongitude = 0;
let currentCountry = "Determining country...";
const options = {
  lat: 0,
  lng: 0,
  zoom: 2,
  style: "http://{s}.tile.osm.org/{z}/{x}/{y}.png"
};

function keyPressed() {
  if (keyCode === 32 && iss) {

    myMap.map.flyTo([iss.latitude, iss.longitude], 4); 
  }
}



let iss;

function setup() {
   canvas = createCanvas(1500, 800);
  startTime = millis();
  myMap = mappa.tileMap(options);
  myMap.overlay(canvas);
  
 
  fetchISSData();
  setInterval(fetchISSData, 2000);
  for (let i = 0; i < 50; i++) {
  velocities.push(random(27500, 27600));
}
}



function fetchISSData() {
  const url = 'https://api.wheretheiss.at/v1/satellites/25544/';
  loadJSON(url, updateISSPosition);
}

function updateISSPosition(data) {
  if (!iss) {
    iss = new Satellite(data.name, data.id, data.latitude, data.longitude, data.velocity, data.visibility);
  } else {
    iss.updatePosition(data.latitude, data.longitude);
  }

  fetchCountry(data.latitude, data.longitude);
}

function fetchCountry(latitude, longitude) {
  const apiKey = '2071da463a2e4193a5fea6d6cb0f110b'
  const baseUrl = 'https://api.geoapify.com/v1/geocode/reverse';
  const url = baseUrl + '?lat=' + latitude + '&lon=' + longitude + '&apiKey=' + apiKey;

  loadJSON(url, processCountryResponse);
}

function processCountryResponse(data) {
  console.log("Country data received:", data); 
  if (data !== null && data.features !== undefined) {
    if (data.features.length > 0) {
      if (data.features[0].properties !== undefined) {
        if (data.features[0].properties.country !== undefined) {
          currentCountry = data.features[0].properties.country;
        } else {
          currentCountry = "Unknown location";
        }
      } else {
        currentCountry = "Unknown location";
      }
    } else {
      currentCountry = "Unknown location";
    }
  } else {
    currentCountry = "Unknown location";
  }
}



function draw() {
  clear();
  colorMode(RGB,255)
  drawTitle();
  fill(0, 255, 0)
  drawGraph()
  resetTextProperties();
  displayElapsedTime()
  if (iss) {
    iss.display(myMap);
    iss.drawLegend();
    fill(0, 100)
    rect(width/2-150, 582.5, 300, 75, 5)
    textSize(16);
    colorMode(HSB, 360, 100, 100);
    fill(0,0,100)
    textAlign(CENTER, CENTER);
    text("Current Country: " + currentCountry, width/2, height-185);
    console.log(currentCountry)
    text("Space Bar To Return To ISS", width/2, height-160)
  }
  
}



function updateVelocity(newVelocity) {
  velocities.push(newVelocity);
  console.log(velocities)
  
  const maxEntries = 50;
  if (velocities.length > maxEntries) {
    velocities.shift();
  }
}

function drawGraph() {
  const graphWidth = 400;
  const graphHeight = 200;
  const graphStartX = 20; 
  const graphStartY = height - graphHeight - 145; 

  fill(0, 100);
  noStroke();
  rect(graphStartX, graphStartY, graphWidth, graphHeight); 

  fill(0, 255, 0); 
  noStroke();
  for (let i = 0; i < velocities.length; i++) {
    const x = map(i, 0, velocities.length - 1, graphStartX, graphStartX + graphWidth);
    const y = map(velocities[i], 0, max(velocities), graphStartY + graphHeight, graphStartY);
    circle(x, y+50, 5); 
  }

  fill(255); 
  noStroke();
  textSize(16);
  textAlign(LEFT, BOTTOM);
  text("Velocity (km/h)", graphStartX+10, graphStartY + 20);
}
