function displayElapsedTime() {
  let elapsedTime = millis() - startTime;
  let seconds = Math.floor(elapsedTime / 1000); 
  let minutes = Math.floor(seconds / 60); 
  seconds = seconds % 60; 

  let minutesString = minutes < 10 ? "0" + minutes : minutes;
  let secondsString = seconds < 10 ? "0" + seconds : seconds;


  let timeString = minutesString + ':' + secondsString;


  textSize(20);
  fill(0,100)
  rect(45, 10, 200, 30)
  fill(255);
  noStroke();
  text("Time Elapsed: " + timeString, 50, 30);
  
}
