

var prices = [];
function fetchData() {

  const apiKey = 'coinranking4872f5eaf701c971b5e88c0b7fb75bd8e3b541603c7bb9c1';

  console.log("Starting data fetch...");
  uuids.forEach((coin, index) => {
    setTimeout(() => {
      const url = `https://api.coinranking.com/v2/coin/${coin.uuid}/price`;
      console.log(`Fetching data for ${coin.name}...`);
      fetch(url, {
        method: 'GET',
        headers: { 'x-access-token': apiKey }
      })
      .then(response => {
        if (!response.ok) {
          console.log(Error(`HTTP error! status: ${response.status}`));
        } else {
          return response.json();
        }
      })
      .then(data => {
        if (data.status === 'success') {
          console.log(`${coin.name}: $${data.data.price}`);
          prices.push(`${coin.name}: $${data.data.price}`);
        } else {
          console.log(`${coin.name}: Price unavailable`);
          prices.push(`${coin.name}: Price unavailable`);
        }
      })
      .catch(error => {
        console.error(`Error fetching data for ${coin.name}:`, error);
        prices.push(`${coin.name}: Error fetching data`);
      });
    }, index * 1000);  // Delay each request by 1 second
  });
}


function display_prices() {
  if (prices.length > 0) {
    fill(0);  
    textSize(16);
    for (let i = 0; i < prices.length; i++) {
      
      let parts = prices[i].split(': $'); 
      if (parts.length === 2) { 
        let name = parts[0];
        let price = parseFloat(parts[1]).toFixed(3);  
        let displayText = `${name}: $${price}`;
        text(displayText, 310, 350 + i * 45);  
      }
    }
  } else {
    fill(255);
    text("Loading prices...", 300, 351 + i * 45);  
  }
}
