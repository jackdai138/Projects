let cryptoArticles = [];

const cryptoQueries = ["Binance", "Bitcoin", "Dogecoin", "Ethereum", "Polkadot", "Solana", "Tether", "USD Coin", "XRP"];

function fetchCryptoHeadlines() {
  for (let i = 0; i < cryptoQueries.length; i++) {
    setTimeout(fetchCryptoNews, i * 1000, cryptoQueries[i]); 
  }
}

function fetchCryptoNews(query) {
  const url = `https://newsapi.org/v2/everything?q=${query}&apiKey=${news_apiKey}`;
  loadJSON(url, function(response) {
    if (response.status === "ok" && response.articles.length > 0) {
      cryptoArticles.push(response.articles[0]); 
      console.log(cryptoArticles);  // Log to console to check
    }
  });
}


function displayCryptoHeadlines() {
  let x = width / 2 - 10 ;
  let y = 234;
  textSize(15);
  for (let i = 0; i < cryptoArticles.length; i++) {
    textStyle(BOLD);
    let coinTitle = cryptoQueries[i];
    fill(0); 
    text(coinTitle, x, y);

    y += 20;

    textStyle(NORMAL);
    let headline = cryptoArticles[i].title;
    let headlineWidth = textWidth(headline);
    if (mouseX > x && mouseX < x + headlineWidth && mouseY > y - 15 && mouseY < y + 5) {
      fill(0, 0, 255); 
      if (mouseIsPressed) {
        window.open(cryptoArticles[i].url, '_blank'); 
      }
    } else {
      fill(0); 
    }
    text(headline, x, y);

    y += 40;  
  }
}
