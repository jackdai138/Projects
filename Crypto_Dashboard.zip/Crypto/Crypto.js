var apiKey = 'coinranking4872f5eaf701c971b5e88c0b7fb75bd8e3b541603c7bb9c1';
var uuids = [
    { name: "Binance Coin", uuid: "WcwrkfNI4FUAe" },
    { name: "Bitcoin", uuid: "Qwsogvtv82FCd" },
    { name: "DogeCoin", uuid: "a91GCGd_u96cF" },
    { name: "Ethereum", uuid: "razxDUgYGNAdQ" },
    { name: "Polkadot", uuid: "25W7FG7om" },
    { name: "Solana", uuid: "zNZHO_Sjf" },
    { name: "Tether", uuid: "HIVsRcGKkPFtW" },
    { name: "USD Coin", uuid: "aKzUVe4Hh_CON" },
    { name: "XRP", uuid: "-l8Mn2pVlRs-p" }
  ];
var timePeriod = '24h';
var coinUuid = 0; //Key for Click
var name_graph = ''
var priceGraphs = []

var screenState = 1
let video;
const vScale = 25;




function setup() {
  createCanvas(1450, 800);
  pixelDensity(1);
  video = createCapture(VIDEO);
  video.size(400 / vScale, 400 / vScale);
  for (let i = 0; i < uuids.length; i++) {
    setTimeout(() => {
      priceGraphs[i] = new PriceGraph(apiKey, uuids[i].uuid, timePeriod, 660, 150, 560, 240); 
      priceGraphs[i].fetchPriceHistory();
    }, i * 1000);  
  }
  
fetchData();
console.log(prices);


  header = new Header('Research Tool');
  contentArea = new ContentArea();
  searchBar = new SearchBar(20, 20, 200, 20, 'Search...');
  fetchHeadlines()
  fetchCryptoHeadlines()


}


function draw() {
  if (screenState == 1){
  background(0)
  dashboard()
  
  display_coins()
  
  displayCoinsVertically()
  
  detectClick(mouseX, mouseY)
  
  if (prices.length > 0) { 
    display_prices();}
    
  graphInfo()
  
  
  
   if (priceGraphs[coinUuid] && priceGraphs[coinUuid].isDataLoaded) {
    priceGraphs[coinUuid].display();
  } else {
    console.log('Waiting for graph data to load...');
  }
  textSize(15)
  fill(0)
    displayHoldings();}
    
   else if(screenState == 0){
    
    header.display();
    console.log(currentHoldings)
    contentArea.display();
    if (articles.length > 0) {
      
    displayHeadlines();
    
    displayCryptoHeadlines()
    
    searchBar.display()
    fill(0)
    rect(0, 50, 663, 330 )
    
      video.loadPixels();
    let posX = 20; 
    let posY = 60; 
    for (let y = 0; y < 310 / vScale; y++) {
    for (let x = 0; x < 630 / vScale; x++) {
      let index = (x + y * (400 / vScale)) * 4;
      let r = video.pixels[index];
      let g = video.pixels[index + 1];
      let b = video.pixels[index + 2];
      let bright = (r + g + b) / 3;
      let diameter = map(bright, 0, 255, 0, vScale);
      noStroke();
      fill(255);
      ellipse(posX + x * vScale, posY + y * vScale, diameter, diameter);
        if (dropdownVisible) {
    drawDropdown();
  }
    }
  }
}

}

drawToggleButton();
}

function keyPressed() {
  if (screenState === 1) {
    updateHoldingsFromKeyInput();
  } else if (screenState === 0) {
    if (key.length === 1) {
      searchBar.updateText(key);
    } else {
      if (keyCode === BACKSPACE) {
        searchBar.updateText(BACKSPACE);
      } else if (keyCode === ENTER) {
        searchBar.updateText(ENTER);
      }
    }
  }
}
