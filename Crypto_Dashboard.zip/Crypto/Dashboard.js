function dashboard() {

  let darkGrey = color(35, 35, 35, 220); 
  let midGrey = color(60, 60, 60, 220); 
  let lightGrey = color(120, 120, 120, 220);
  let accentColor = color(0, 255, 255);

  noStroke(); 
  
  // Sidebar
  fill(darkGrey);
  rect(0, 0, 200, height); 
  

  // Header
  fill(midGrey);
  rect(200, 0, width - 200, 100); 

  // Title
  fill(255);
  textSize(30);
  text('Cryptocurrency Dashboard', width/2-100, 60);

  // Balance Box
  fill(midGrey);
  rect(220, 120, 350, 150, 10); // Rounded corners
  fill(accentColor);
  textSize(20);
  text('Profile Balance', 240, 150);
  textSize(30);
  displayTotalValue()

  // Graph Area
  fill(darkGrey);
  rect(600, 120, 630, 300); // Placeholder for graph
  stroke(accentColor);
  noFill();
  beginShape();
  // Add vertices for the graph
  endShape();

  // Assets and Operations
  stroke(0,255,0)
  fill(240);
  rect(220, 300, 350, 450); // Price background
  rect(600, 450, 280, 300); // Price Change background
  rect(900, 450, 360, 300);// Possession background
  

  fill(lightGrey);
  textSize(18);
  text('Price', 240, 320);
  text('24h Price Data', 620, 470);

  // Example button
  fill(lightGrey);
  rect(220, 770, 100, 20, 5);
  fill(darkGrey);
  textSize(14);
  text('Refresh', 240, 785);

  // White borders 
  stroke(255); 
  strokeWeight(2); // stroke weight for visibility

  noFill(); 
  rect(220, 120, 350, 150, 10); // Balance Box border
  rect(600, 120, 630, 300); // Graph Area border
  rect(220, 300, 350, 450); // Price
  rect(600, 450, 280, 300); // Operations border

}
