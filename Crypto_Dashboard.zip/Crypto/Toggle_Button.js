function drawToggleButton() {
  noStroke()
  let buttonX = width - 200; 
  let buttonY = 0; 
  let buttonWidth = 120; 
  let buttonHeight = 50; 
  let depth = 10; 


  let isHovering = mouseX > buttonX && mouseX < buttonX + buttonWidth &&
                   mouseY > buttonY && mouseY < buttonY + buttonHeight + depth;

  let topColor = isHovering ? '#FFFFFF' : '#D0D3D4'; 
  let sideColor = '#B0B3B4'; 


  fill(topColor);
  rect(buttonX, buttonY, buttonWidth, buttonHeight);


  fill(sideColor);
  beginShape(); 
  
  vertex(buttonX + buttonWidth, buttonY);
  
  vertex(buttonX + buttonWidth + depth, buttonY - depth);
  
  vertex(buttonX + buttonWidth + depth, buttonY + buttonHeight - depth);
  
  vertex(buttonX + buttonWidth, buttonY + buttonHeight);
  
  endShape(CLOSE);

  beginShape();
  vertex(buttonX, buttonY + buttonHeight);
  
  vertex(buttonX + depth, buttonY + buttonHeight - depth);
  
  vertex(buttonX + buttonWidth + depth, buttonY + buttonHeight - depth);
  
  vertex(buttonX + buttonWidth, buttonY + buttonHeight);
  
  endShape(CLOSE);


  fill('#000000'); 
  textSize(16);
  textStyle(BOLD);


  let textX = buttonX + buttonWidth / 2 - textWidth(screenState === 0 ? "Dashboard" : "Tool") / 2;
  let textY = buttonY + buttonHeight / 2 + 6; 

  text(screenState === 0 ? "Dashboard" : "Tool", textX, textY);
}

function mousePressed() {
  let buttonX = width - 200;
  let buttonY = 0;
  let buttonWidth = 120;
  let buttonHeight = 50;


  if (mouseX > buttonX && mouseX < buttonX + buttonWidth && mouseY > buttonY && mouseY < buttonY + buttonHeight) {
    toggleScreenState();
  }
}

function toggleScreenState() {
  screenState = 1 - screenState;
}
