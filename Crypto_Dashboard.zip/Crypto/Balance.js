var userHoldings = [0, 0, 0, 0, 0, 0, 0, 0, 0];
var totalValue = 0;
var currentHoldings = []; 


function updateHoldingsFromKeyInput() {
  const asciiCode = unchar(key);  
  const index = asciiCode - unchar('0');
  
  if (index >= 0 && index < prices.length) {  
    
    const coinName = prices[index].split(":")[0];
    
    const userInput = prompt(`${coinName} Amount:`);
    const amount = parseFloat(userInput);

    if (!isNaN(amount) && amount >= 0) {
      userHoldings[index] = amount;
      currentHoldings[index] = coinName; 
      calculateAndDisplayTotalValue();
    }
}}


function calculateAndDisplayTotalValue() {
    calculateTotalValue();
    redraw(); 
}

function calculateTotalValue() {
    totalValue = 0;
    userHoldings.forEach((holding, index) => {
      
        const price = parseFloat(prices[index].split(": $")[1]);
        totalValue += holding * price;
    });
}


function displayTotalValue() {
    text(`$${totalValue.toFixed(2)}`, 240, 180);
}

function displayHoldings() {
     fill(82, 43, 41)
     
    text(`Press keys 0-8 to update holdings`, 910, 740);
    prices.forEach((price, index) => {
        const coinName = price.split(":")[0];
        fill(29, 51, 84)
        text(`${coinName}: ${userHoldings[index]} units`, 910, 472 + index * 30);
    });
}
