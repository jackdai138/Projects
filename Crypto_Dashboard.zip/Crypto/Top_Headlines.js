var articles = [];
var news_apiKey = 'da16f38f7aa54715938afdc8415618e7';


var sources = ["bloomberg", "business-insider", "fortune", "financial-post", "the-wall-street-journal"];

function fetchHeadlines() {
  for (var i = 0; i < sources.length; i++) {
    setTimeout(fetchNews, i * 1000, sources[i]); 
  }
}

function fetchNews(source) {
  const url = `https://newsapi.org/v2/top-headlines?sources=${source}&apiKey=${news_apiKey}`;
  

  function loadData() {
    loadJSON(url, function(response) {
      if (response.status === "ok" && response.articles.length > 0) {
        articles.push(response.articles[0]); 
        console.log(articles);  // Log to console to check
      }
    });
  }

  setTimeout(() => {
    loadData();
  }, 1000); 
}



function displayHeadlines() {
  let y = height / 2 + 50;
  textSize(15);
  for (var i = 0; i < articles.length; i++) {

    textStyle(BOLD);
    let sourceName = articles[i].source.name;
    fill(0); 
    text(sourceName, 20, y);

    y += 20;

    //Create a clickable headline
    textStyle(NORMAL);
    let headline = articles[i].title;
    let headlineWidth = textWidth(headline);
    if (mouseX > 10 && mouseX < headlineWidth + 10 && mouseY > y - 15 && mouseY < y + 5) {
      fill(0, 0, 255); 
      if (mouseIsPressed) {
        window.open(articles[i].url, '_blank'); 
      }
    } else {
      fill(0); 
    }
    text(headline, 20, y);

    y += 40;  
  }
}
