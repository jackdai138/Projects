
var coin_asset = []
var detect = false
var lastClickedIndex = -1;
const iconPositions = [
  { x: 620, y: 525, width: 40, height: 40 },
  { x: 720, y: 525, width: 40, height: 40 },
  { x: 820, y: 525, width: 40, height: 40 },
  { x: 620, y: 585, width: 40, height: 40 },
  { x: 720, y: 585, width: 40, height: 40 },
  { x: 820, y: 585, width: 40, height: 40 },
  { x: 620, y: 645, width: 40, height: 40 },
  { x: 720, y: 645, width: 40, height: 40 },
  { x: 820, y: 645, width: 40, height: 40 }
];


function mouseClicked() {
  console.log("Mouse click detected.");
  let iconIndex = detectClick(mouseX, mouseY);
  if (iconIndex !== -1 && iconIndex !== lastClickedIndex) {
    console.log("Mouse clicked within icon at index", iconIndex);
    graphInfo(iconIndex);
    lastClickedIndex = iconIndex; // Update the last clicked index.
  } else if (iconIndex === -1) {
    console.log("Mouse clicked outside of any icons");
    lastClickedIndex = -1; // Reset if clicked outside of icon
  }
  
  if(screenState==0){
    if (mouseX > dropdownX && mouseX < dropdownX + dropdownWidth && mouseY > dropdownY && mouseY < dropdownY + dropdownHeight) {
    dropdownVisible = !dropdownVisible;
  } else {
    dropdownVisible = false;
  }
  for (let i = 0; i < searchEngines.length; i++) {
    let y = dropdownY + i * itemHeight;
    if (mouseX > dropdownX && mouseX < dropdownX + dropdownWidth && mouseY > y && mouseY < y + itemHeight) {
      activeSearchEngine = searchEngines[i];
    }
  }
  
  }
}


function detectClick(mouseX, mouseY) {
    if (mouseX >= iconPositions[0].x && mouseX <= iconPositions[0].x + iconPositions[0].width &&
        mouseY >= iconPositions[0].y && mouseY <= iconPositions[0].y + iconPositions[0].height) {
        return 0;
    }
    if (mouseX >= iconPositions[1].x && mouseX <= iconPositions[1].x + iconPositions[1].width &&
        mouseY >= iconPositions[1].y && mouseY <= iconPositions[1].y + iconPositions[1].height) {
        console.log("Mouse clicked within icon at index 1");
        detect = true
        return 1;
    }
    
     if (mouseX >= iconPositions[2].x && mouseX <= iconPositions[2].x + iconPositions[2].width &&
        mouseY >= iconPositions[2].y && mouseY <= iconPositions[2].y + iconPositions[2].height) {
        console.log("Mouse clicked within icon at index 2");
        detect = true
        return 2;
    }
    
     if (mouseX >= iconPositions[3].x && mouseX <= iconPositions[3].x + iconPositions[3].width &&
        mouseY >= iconPositions[3].y && mouseY <= iconPositions[3].y + iconPositions[3].height) {
        console.log("Mouse clicked within icon at index 3");
        detect = true
        return 3;
    }
    
     if (mouseX >= iconPositions[4].x && mouseX <= iconPositions[4].x + iconPositions[4].width &&
        mouseY >= iconPositions[4].y && mouseY <= iconPositions[4].y + iconPositions[4].height) {
        console.log("Mouse clicked within icon at index 4");
        detect = true
        return 4;
    }
    
    
 if (mouseX >= iconPositions[5].x && mouseX <= iconPositions[5].x + iconPositions[5].width &&
        mouseY >= iconPositions[5].y && mouseY <= iconPositions[5].y + iconPositions[5].height) {
        console.log("Mouse clicked within icon at index 5");
        detect = true
        return 5;
    }
    
     if (mouseX >= iconPositions[6].x && mouseX <= iconPositions[6].x + iconPositions[6].width &&
        mouseY >= iconPositions[6].y && mouseY <= iconPositions[6].y + iconPositions[6].height) {
        console.log("Mouse clicked within icon at index 6");
        detect = true
        return 6;
    }
    
         if (mouseX >= iconPositions[7].x && mouseX <= iconPositions[7].x + iconPositions[7].width &&
        mouseY >= iconPositions[7].y && mouseY <= iconPositions[7].y + iconPositions[7].height) {
        console.log("Mouse clicked within icon at index 7");
        detect = true
        return 7;
    }
    
    
    if (mouseX >= iconPositions[8].x && mouseX <= iconPositions[8].x + iconPositions[8].width &&
        mouseY >= iconPositions[8].y && mouseY <= iconPositions[8].y + iconPositions[8].height) {
        console.log("Mouse clicked within icon at index 8");
        detect = true
        return 8;
        
    }
}



function graphInfo(index) {
  switch (index) {
    case 0:
      console.log("Action for icon 0");
      coinUuid = index
      console.log(coinUuid)
      break;
    case 1:
      console.log("Action for icon 1");
      coinUuid = index
      console.log(coinUuid)
      break;
    case 2:
      console.log("Action for icon 2");
      coinUuid = index
      console.log(coinUuid)
      break;
    case 3:
      console.log("Action for icon 3");
      coinUuid = index
      console.log(coinUuid)
      break;
    case 4:
      console.log("Action for icon 4");
      coinUuid = index
      console.log(coinUuid)
      break;
    case 5:
      console.log("Action for icon 5");
      coinUuid = index
      console.log(coinUuid)
      break;
    case 6:
      console.log("Action for icon 6");
      coinUuid = index
      console.log(coinUuid)
      break;
    case 7:
      console.log("Action for icon 7");
      coinUuid = index
      console.log(coinUuid)
      break;
    case 8:
      console.log("Action for icon 8");
      coinUuid = index
      console.log(coinUuid)
      break;

  }
}
