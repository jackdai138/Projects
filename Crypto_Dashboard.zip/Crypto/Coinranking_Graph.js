class PriceGraph {
  constructor(apiKey, coinUuid, timePeriod, x, y, width, height) {
    this.apiKey = apiKey;
    this.coinUuid = coinUuid;
    this.timePeriod = timePeriod;
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.priceHistory = [];
    this.maxPrice = 0;
    this.minPrice = Infinity;
    this.isDataLoaded = false;
  }

  fetchPriceHistory() {
    const url = `https://api.coinranking.com/v2/coin/${this.coinUuid}/history?timePeriod=${this.timePeriod}`;
    fetch(url, {
      method: 'GET',
      headers: { 'x-access-token': this.apiKey }
    })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        
        this.priceHistory = data.data.history;
        this.maxPrice = Math.max(...this.priceHistory.map(p => parseFloat(p.price)));
        this.minPrice = Math.min(...this.priceHistory.map(p => parseFloat(p.price)));
        this.isDataLoaded = true;
        
      } else {
        console.error('Failed to load data:', data);
      }
    })
    .catch(error => {
      console.error('Error fetching data:', error);
    });
  }

  display() {
    if (this.isDataLoaded) {
      this.drawGraph();
      this.drawLabels();
      this.drawGrid();
    } else {
      this.displayLoading();
    }
  }

  drawGraph() {
    stroke(0, 100, 200);
    strokeWeight(2);
    noFill();
    beginShape();
    for (let i = 0; i < this.priceHistory.length; i++) {
      let point = this.priceHistory[i];
      let x = map(i, 0, this.priceHistory.length - 1, this.x, this.x + this.width);
      let y = map(point.price, this.minPrice, this.maxPrice, this.y + this.height, this.y);
      vertex(x, y);
    }
    endShape();
  }

  drawLabels() {
    fill(0, 255, 0);
    textSize(12);
    noStroke();
    text(`Max: $${this.maxPrice.toFixed(3)}`, this.x, this.y - 10);
    fill(255, 0, 0);
    text(`Min: $${this.minPrice.toFixed(3)}`, this.x, this.y + this.height + 20);
  }

  drawGrid() {
    stroke(200);
    strokeWeight(0.5);
    for (let i = 0; i <= 10; i++) {
      let y = map(i, 0, 10, this.y + this.height, this.y);
      line(this.x, y, this.x + this.width, y);
      noStroke();
      fill(255);
      textSize(10);
      text((this.minPrice + i * (this.maxPrice - this.minPrice) / 10).toFixed(3), this.x - 50, y);
    }
  }

  displayLoading() {
    fill(255);
    noStroke();
    textSize(16);
    text("Loading prices...", this.x + 20, this.y + this.height / 2);
  }
}
