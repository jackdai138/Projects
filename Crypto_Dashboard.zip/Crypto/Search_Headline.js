let searchEngines = ["Google", "Bing", "Yahoo", "DuckDuckGo"];
let activeSearchEngine = "Google";
var dropdownVisible = false;
let dropdownX = 300;
let dropdownY = 20;
let dropdownWidth = 120;
let dropdownHeight = 20;
let itemHeight = 20;





function handleSearch() {
  switch (activeSearchEngine) {
    case "Google":
      window.open(`https://www.google.com/search?q=${encodeURIComponent(searchBar.searchQuery)}`, '_blank');
      break;
    case "Bing":
      window.open(`https://www.bing.com/search?q=${encodeURIComponent(searchBar.searchQuery)}`, '_blank');
      break;
    case "Yahoo":
      window.open(`https://search.yahoo.com/search?p=${encodeURIComponent(searchBar.searchQuery)}`, '_blank');
      break;
    case "DuckDuckGo":
      window.open(`https://duckduckgo.com/?q=${encodeURIComponent(searchBar.searchQuery)}`, '_blank');
      break;
    default:
      console.error("Invalid search engine selected");
  }
}

function handleSearchEngineChange() {
  activeSearchEngine = searchEngineDropdown.value();
}

function keyPressed() {
  if (keyCode === ENTER) {
    searchBar.handleSearch();
  }
}


function drawDropdown() {
  // Draw dropdown background
  fill(255);
  stroke(0);
  rect(dropdownX, dropdownY, dropdownWidth, itemHeight * searchEngines.length);
  
  for (let i = 0; i < searchEngines.length; i++) {
    let y = dropdownY + i * itemHeight;
    let textColor = (mouseX > dropdownX && mouseX < dropdownX + dropdownWidth && mouseY > y && mouseY < y + itemHeight) ? color(200) : color(0);
    let bgColor;
    switch (searchEngines[i]) {
      case "Google":
        bgColor = color(255, 100, 100); // Red
        break;
      case "Bing":
        bgColor = color(100, 255, 100); // Green
        break;
      case "Yahoo":
        bgColor = color(100, 100, 255); // Blue
        break;
      case "DuckDuckGo":
        bgColor = color(255, 255, 100); // Yellow
        break;
      default:
        bgColor = color(255); // White
    }
    fill(bgColor);
    rect(dropdownX, y, dropdownWidth, itemHeight);
    fill(textColor);
    text(searchEngines[i], dropdownX + 5, y + 15);
  }
  
  // Draw down arrow
  fill(0);
  triangle(dropdownX + dropdownWidth - 15, dropdownY + 7, dropdownX + dropdownWidth - 10, dropdownY + 7, dropdownX + dropdownWidth - 12.5, dropdownY + 12);
  
  // Draw hover effect for "Choose Engine" text
  if (dropdownVisible == false && mouseX > dropdownX && mouseX < dropdownX + dropdownWidth && mouseY > dropdownY && mouseY < dropdownY + itemHeight) {
    fill(200); // Hover effect color
    rect(this.x + 275, this.y - 10, this.w - 80, this.h + 10);
    fill(0);
    text("Choose Engine", this.x + 280, this.y + 10);
  }
}
