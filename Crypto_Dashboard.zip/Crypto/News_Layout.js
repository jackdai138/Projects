var header;
var contentArea;
var searchBar;
var searchQuery = "";

class Header {
  constructor(title) {
    this.title = title;
  }

  display() {
    fill(35, 35, 35, 220);
    rect(0, 0, width, 50);
    fill(255);
    textSize(24);
    text(this.title, width / 2 - textWidth(this.title) / 2, 25);
  }
}

class ContentArea {
  display() {
    fill(255);
    rect(0, 50, width - 150, height - 50);
    fill(0);
    textSize(16);
    text("Finance Headlines", 20, height/2+10); 
    text("Industry Headlines", width/2-10, 157.5); 
    stroke(0); 
    strokeWeight(5);
    line(0,height/2-20, width/2-60, height/2-20);
    line(width/2-60,50, width/2-60, height);
    strokeWeight(0.75)
  }
}


class SearchBar {
  constructor(x, y, w, h, placeholder) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.placeholder = placeholder;
    this.text = ""; 
    this.cursorVisible = true; 
    this.lastTimeCursorChanged = millis(); 
    this.searchQuery = ""; 
  }

updateText(char) {
  if (/[a-zA-Z]/.test(char)) {
    this.text += char; 
  } else if (char === BACKSPACE && this.text.length > 0) {
    this.text = this.text.substring(0, this.text.length - 1); 
  } else if (char === ENTER) {
    this.searchQuery = this.text; 
    this.text = ""; 
    handleSearch()
  }
}


  display() {
    
  if (dropdownVisible == false) {
    if (mouseX > dropdownX && mouseX < dropdownX + dropdownWidth && mouseY > dropdownY && mouseY < dropdownY + itemHeight) {
      fill(220); }
    else{
       fill(255)
    }
     rect(this.x + 275, this.y - 10, this.w - 80, this.h + 10);
     fill(0);
     text(activeSearchEngine, this.x + 280, this.y + 10);
    }
  
    
    fill(255);
    rect(this.x, this.y, this.w, this.h);
    textSize(16)
    text("Search", this.x+ 210, this.y+5 + this.h / 2)
    fill(0);
    textSize(14);
    text(this.text, this.x + 10, this.y+5 + this.h / 2);

    if (this.cursorVisible) {
      let cursorX = this.x + textWidth(this.text) + 10;
      stroke(0);
      line(cursorX, this.y + 5, cursorX, this.y + this.h - 5);
    }

    if (millis() - this.lastTimeCursorChanged > 500) {
      this.cursorVisible = !this.cursorVisible;
      this.lastTimeCursorChanged = millis();
    }
  }
}
