var bin = "binance.png"
var bit = "bitcoin.png"
var doge = "doge.png"
var eth = "ethereum.png"
var polka = "polkadot.png"
var sol = "solana.png"
var teth = "tether.png"
var usd = "usd.png"
var xrp = "xrp.png"
var iconPosition
var coin_loaded = []
var customCursor;

function preload(){
 shuttle = loadFont('SHUTTLE-X.otf')
 
 coin_loaded.push(loadImage(bin))
 
 coin_loaded.push(loadImage(bit))
 
 coin_loaded.push(loadImage(doge))
 
 coin_loaded.push(loadImage(eth))
 
 coin_loaded.push(loadImage(polka))
 
 coin_loaded.push(loadImage(sol))
 
 coin_loaded.push(loadImage(teth))
 
 coin_loaded.push(loadImage(usd))
 
 coin_loaded.push(loadImage(xrp))
 
 customCursor = loadImage('cursor.png')
}




function display_coins() {
  let numRows = 3; 
  let numCols = 3; 
  let imageIndex = 0; 
  let iconWidth = 40; 
  let iconHeight = 40; 
  iconPosition = []; 

  for (var row = 0; row < numRows; row++) {
    for (var col = 0; col < numCols; col++) {
      if (imageIndex < coin_loaded.length) {
        let xPos = 620 + col * 100; // 100 spacing
        let yPos = 525 + row * 60;
        image(coin_loaded[imageIndex], xPos, yPos, iconWidth, iconHeight);
        // Store each icon's position
        iconPosition.push({
          x: xPos,
          y: yPos,
          width: iconWidth,
          height: iconHeight,
          image: coin_loaded[imageIndex]
        });
        imageIndex++; // Move to the next image index
      }
    }
  }
}




function displayCoinsVertically() {
  let xPosition = 240; 
  let yStart = 330;
  let spacing = 45; // Vertical space

  iconPosition = []; // Initialize or reset

  for (let i = 0; i < coin_loaded.length; i++) {
    let yPos = yStart + i * spacing; // Calculate y pos
    image(coin_loaded[i], xPosition, yPos, 32, 32); 

  }
}
